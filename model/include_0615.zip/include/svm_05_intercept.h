#ifndef SVM_INCLUDE_GUARD_SVM_05_INTERCEPT_H
#define SVM_INCLUDE_GUARD_SVM_05_INTERCEPT_H

#ifdef _MSC_VER
__declspec(align(4))
#else
__attribute__((aligned(4)))
#endif
static const unsigned char intercept_float32_bin[] = {
0x5e,0xd5,0x10,0x3f,};
#endif // SVM_INCLUDE_GUARD_SVM_05_INTERCEPT_H
