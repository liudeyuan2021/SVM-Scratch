#ifndef SVM_INCLUDE_GUARD_SVM_03_NSV_H
#define SVM_INCLUDE_GUARD_SVM_03_NSV_H

#ifdef _MSC_VER
__declspec(align(4))
#else
__attribute__((aligned(4)))
#endif
static const unsigned char nSV_int32_bin[] = {
0x9e,0x00,0x00,0x00,0x73,0x00,0x00,0x00,};
#endif // SVM_INCLUDE_GUARD_SVM_03_NSV_H
