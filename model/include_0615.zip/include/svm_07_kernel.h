#ifndef SVM_INCLUDE_GUARD_SVM_07_KERNEL_H
#define SVM_INCLUDE_GUARD_SVM_07_KERNEL_H

#ifdef _MSC_VER
__declspec(align(4))
#else
__attribute__((aligned(4)))
#endif
static const unsigned char kernel_int32_string_bin[] = {
0x72,0x00,0x00,0x00,0x62,0x00,0x00,0x00,0x66,0x00,0x00,0x00,};
#endif // SVM_INCLUDE_GUARD_SVM_07_KERNEL_H
