#ifndef SVM_INCLUDE_GUARD_SVM_09_GAMMA_H
#define SVM_INCLUDE_GUARD_SVM_09_GAMMA_H

#ifdef _MSC_VER
__declspec(align(4))
#else
__attribute__((aligned(4)))
#endif
static const unsigned char gamma_float32_bin[] = {
0xdf,0x89,0x5e,0x3c,};
#endif // SVM_INCLUDE_GUARD_SVM_09_GAMMA_H
