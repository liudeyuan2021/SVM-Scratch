#ifndef SVM_INCLUDE_GUARD_SVM_08_DEGREE_H
#define SVM_INCLUDE_GUARD_SVM_08_DEGREE_H

#ifdef _MSC_VER
__declspec(align(4))
#else
__attribute__((aligned(4)))
#endif
static const unsigned char degree_int32_bin[] = {
0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,};
#endif // SVM_INCLUDE_GUARD_SVM_08_DEGREE_H
